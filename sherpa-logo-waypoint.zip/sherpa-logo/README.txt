Sherpa logo — Waypoint

svg/  vector files (use these whenever you can)
  sherpa-mark*.svg          the mark alone (light bg / dark bg / white / black)
  sherpa-logo*.svg          mark + "sherpa" wordmark (text converted to outlines, no font needed)
  sherpa-app-icon*.svg      rounded-square app icon, 1024x1024
png/  ready-made PNG exports (transparent background unless the name says with-bg)
sherpa.ico                Windows icon (16-256 px) for the installer / exe / favicon

Colours
  Night   #0E1320
  Signal  #FF6B4A
  Snow    #EEF1F8
Font: Sora SemiBold (600), letter-spacing about -0.04em
